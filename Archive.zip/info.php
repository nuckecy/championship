<style>
    @import url('https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300');
body {
    font-family: 'Open Sans Condensed', sans-serif;
    background: #053a00;
    margin: 150px auto;
    color: #fff;
    text-align: center;
}
</style>
<h1>Portal Opens at 5pm, 8th December 2018</h1>
<p>Here is what you need to know before registering</p>
<div style="width:350px; padding:10px; margin:0 auto; text-align:left;word-wrap: break-word;">
<ol>
    <li>Registration is Open to the 1st 8 TEAMS.</li>
    <li>A team MUST be 15 players.</li>
    <li>Only the COACH or TEAM CAPTAIN will register all the players.</li>
    <li>Team members information MUST be provided on the Portal before they are considered a Team.</li>
    <li>Portal will close when 8 TEAMS have completed their registration.</li>
    <li>Team Member information required are First & Last Names, Email address and Mobile Number</li>
</ol>
</div>
